package com.karan.helpdesk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpdeskApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpdeskApiApplication.class, args);
	}

}
